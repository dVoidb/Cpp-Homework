﻿// ConsoleApplication1.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include <cmath>
#include "ConsoleApplication1.h"


using namespace std;

int main()
{
   //Задание №1
	setlocale(LC_ALL, "Rus");

	try
	{
		double t, l;
		cout << "ВВедите значение переменной t" << endl;
		cin >> t;
		cout << "ВВедите значение переменной l" << endl;
		cin >> l;
		cout <<"R="<< 3* pow(t,2)+pow(l,5)+4.9 << endl;
	}
	catch (const std::exception&)
	{
		cout <<"Ощибка входных данных" << endl;
	}

	system("pause");

	//Задание №2
	try
	{
		double p, y;
		cout << "ВВедите значение переменной p" << endl;
		cin >> p;
		cout << "ВВедите значение переменной y" << endl;
		cin >> y;
		cout << "K="<<log(pow(p,2)+pow(y,3))+exp(p) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ощибка входных данных" << endl;
	}
	system("pause");

	//Задание №3
	try
	{
		double n, y;
		cout << "ВВедите значение переменной n" << endl;
		cin >> n;
		cout << "ВВедите значение переменной y" << endl;
		cin >> y;
		cout << "G=" <<n*(y+3.5)+pow(y,(1/2)) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ощибка входных данных" << endl;
	}
	system("pause");

	//Задание №4
	try
	{
		double a, t;
		cout << "ВВедите значение переменной a" << endl;
		cin >> a;
		cout << "ВВедите значение переменной t" << endl;
		cin >> t;
		cout << "D=" <<9.8*pow(a,2)+5.52*cos(t) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ощибка входных данных" << endl;
	}
	system("pause");

	//Задание №5
	try
	{
		double  x;
		cout << "ВВедите значение переменной x" << endl;
		cin >> x;
		cout << "L=" << 1.51*cos(pow(x,2))+2*pow(x,3)<< endl;
	}
	catch (const std::exception&)
	{
		cout << "Ощибка входных данных" << endl;
	}
	system("pause");

	//Задание №6
	try
	{
		double x, y;
		cout << "ВВедите значение переменной x" << endl;
		cin >> x;
		cout << "ВВедите значение переменной y" << endl;
		cin >> y;
		cout << "M=" <<cos(2*y)+3.6*exp(x) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ощибка входных данных" << endl;
	}
	system("pause");

	//Задание №7
	try
	{
		double  m;
		cout << "ВВедите значение переменной m" << endl;
		cin >> m;
		cout << "N=" <<pow(m,2)+2.8*fabs(m)+0.55 << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ощибка входных данных" << endl;
	}
	system("pause");

	//Задание №8
	try
	{
		double y;
		cout << "ВВедите значение переменной y" << endl;
		cin >> y;
		cout << "T=" << pow(6*pow(y,2)-0.1*y+4, 1 / 2) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ощибка входных данных" << endl;
	}
	system("pause");

	//Задание №9
	try
	{
		double x, y;
		cout << "ВВедите значение переменной x" << endl;
		cin >> x;
		cout << "ВВедите значение переменной y" << endl;
		cin >> y;
		cout << "V=" << log(y+0.95)+pow(sin(x),2)<< endl;
	}
	catch (const std::exception&)
	{
		cout << "Ощибка входных данных" << endl;
	}
	system("pause");

	//Задание №10
	try
	{
		double x, y, k;
		cout << "ВВедите значение переменной x" << endl;
		cin >> x;
		cout << "ВВедите значение переменной y" << endl;
		cin >> y;
		cout << "ВВедите значение переменной k" << endl;
		cin >> k;
		cout << "U=" <<exp(y)+7.355*pow(k,2)+sin(pow(x,4)) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ощибка входных данных" << endl;
	}
	system("pause");

	//Задание №11
	try
	{
		double x, y;
		cout << "ВВедите значение переменной x" << endl;
		cin >> x;
		cout << "ВВедите значение переменной y" << endl;
		cin >> y;
		cout << "S=" << 9.756*pow(y,7)+2*tan(x)<< endl;
	}
	catch (const std::exception&)
	{
		cout << "Ощибка входных данных" << endl;
	}
	system("pause");

	//Задание №12
	try
	{
		double x, t;
		cout << "ВВедите значение переменной x" << endl;
		cin >> x;
		cout << "ВВедите значение переменной t" << endl;
		cin >> t;
		cout << "K=" << 7*pow(t,2)+3*sin(pow(x,3))+9.2 << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ощибка входных данных" << endl;
	}
	system("pause");

	//Задание №13
	try
	{
		double x, y;
		cout << "ВВедите значение переменной x" << endl;
		cin >> x;
		cout << "ВВедите значение переменной y" << endl;
		cin >> y;
		cout << "E=" << pow(fabs(3*pow(y,2)+0.5*y+4), (1 / 2)) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ощибка входных данных" << endl;
	}
	system("pause");

	//Задание №14
	try
	{
		double x, y;
		cout << "ВВедите значение переменной x" << endl;
		cin >> x;
		cout << "ВВедите значение переменной y" << endl;
		cin >> y;
		cout << "R=" <<fabs(pow(pow(sin(y),2)+6.835+exp(x), (1 / 2))) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ощибка входных данных" << endl;
	}
	system("pause");

	//Задание №15
	try
	{
		double  y;
		cout << "ВВедите значение переменной y" << endl;
		cin >> y;
		cout << "H=" << sin(pow(y,2))-2.8*y+pow(fabs(y), (1 / 2)) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ощибка входных данных" << endl;
	}
	system("pause");

	//Задание №16
	try
	{
		double y;
		cout << "ВВедите значение переменной y" << endl;
		cin >> y;
		cout << "S=" << pow(cos(4*pow(y,2))+7.151, (1 / 2)) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ощибка входных данных" << endl;
	}
	system("pause");

	//Задание №17
	try
	{
		double  y;
		cout << "ВВедите значение переменной y" << endl;
		cin >> y;
		cout << "N=" << 3*pow(y,2)+pow(y+1,(1/2))<< endl;
	}
	catch (const std::exception&)
	{
		cout << "Ощибка входных данных" << endl;
	}
	system("pause");

	//Задание №18
	try
	{
		double  y;
		cout << "ВВедите значение переменной y" << endl;
		cin >> y;
		cout << "Z=" << 3 * pow(y, 2) + pow(pow(y,3) + 1, (1 / 2)) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ощибка входных данных" << endl;
	}
	system("pause");

	//Задание №19
	try
	{
		double n, y,g;
		cout << "ВВедите значение переменной x" << endl;
		cin >> n;
		cout << "ВВедите значение переменной y" << endl;
		cin >> y;
		cout << "ВВедите значение переменной g" << endl;
		cin >> g;
		cout << "P=" << n*pow(pow(y,3)+1.09*g, (1 / 2)) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ощибка входных данных" << endl;
	}
	system("pause");

	//Задание №20
	try
	{
		double x, y,k;
		cout << "ВВедите значение переменной x" << endl;
		cin >> x;
		cout << "ВВедите значение переменной y" << endl;
		cin >> y;
		cout << "ВВедите значение переменной k" << endl;
		cin >> k;
		cout << "U=" << exp(k+y)+tan(x*pow(y,(1/2))) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ощибка входных данных" << endl;
	}
	system("pause");

	//Задание №21
	try
	{
		double h, y;
		cout << "ВВедите значение переменной h" << endl;
		cin >> h;
		cout << "ВВедите значение переменной y" << endl;
		cin >> y;
		cout << "P=" << exp(y+5.5)+9.1*pow(h,3) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ощибка входных данных" << endl;
	}
	system("pause");

	//Задание №22
	try
	{
		double x, y, u;
		cout << "ВВедите значение переменной x" << endl;
		cin >> x;
		cout << "ВВедите значение переменной y" << endl;
		cin >> y;
		cout << "ВВедите значение переменной u" << endl;
		cin >> u;
		cout << "T=" << sin(2*u)*log(2*pow(y,2)+pow(x,(1/2)))<< endl;
	}
	catch (const std::exception&)
	{
		cout << "Ощибка входных данных" << endl;
	}
	system("pause");

	//Задание №23
	try
	{
		double f, y;
		cout << "ВВедите значение переменной f" << endl;
		cin >> f;
		cout << "ВВедите значение переменной y" << endl;
		cin >> y;
		cout << "G=" << exp(2*y)+sin(f) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ощибка входных данных" << endl;
	}
	system("pause");

	//Задание №24
	try
	{
		double  y;
		cout << "ВВедите значение переменной y" << endl;
		cin >> y;
		cout << "F=" << 2*sin(0.214*pow(y,5)+1) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ощибка входных данных" << endl;
	}
	system("pause");

	//Задание №25
	try
	{
		double f, y;
		cout << "ВВедите значение переменной f" << endl;
		cin >> f;
		cout << "ВВедите значение переменной y" << endl;
		cin >> y;
		cout << "G=" << exp(2 * y) + sin(pow(f,2)) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ощибка входных данных" << endl;
	}
	system("pause");

	//Задание №26
	try
	{
		double p;
		cout << "ВВедите значение переменной p" << endl;
		cin >> p;
		cout << "Z=" << sin(pow((pow(p,2)+0.4), 3)) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ощибка входных данных" << endl;
	}
	system("pause");

	//Задание №27
	try
	{
		double x, y, v;
		cout << "ВВедите значение переменной x" << endl;
		cin >> x;
		cout << "ВВедите значение переменной y" << endl;
		cin >> y;
		cout << "ВВедите значение переменной v" << endl;
		cin >> v;
		cout << "W=" << 1.03*v+exp(2*y)+tan(fabs(x)) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ощибка входных данных" << endl;
	}
	system("pause");

	//Задание №28
	try
	{
		double h, y;
		cout << "ВВедите значение переменной h" << endl;
		cin >> h;
		cout << "ВВедите значение переменной y" << endl;
		cin >> y;
		cout << "T=" << exp(y+h)+pow(fabs(6.4*y), (1 / 2)) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ощибка входных данных" << endl;
	}
	system("pause");

	//Задание №29
	try
	{
		double y;
		cout << "ВВедите значение переменной y" << endl;
		cin >> y;
		cout << "N=" << 3*pow(y,2)+pow(fabs(y+1), (1 / 2)) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ощибка входных данных" << endl;
	}
	system("pause");

	//Задание №30
	try
	{
		double r, y;
		cout << "ВВедите значение переменной r" << endl;
		cin >> r;
		cout << "ВВедите значение переменной y" << endl;
		cin >> y;
		cout << "W=" << exp(y+r)+7.2*sin(r) << endl;
	}
	catch (const std::exception&)
	{
		cout << "Ощибка входных данных" << endl;
	}
	system("pause");
}

// Запуск программы: CTRL+F5 или меню "Отладка" > "Запуск без отладки"
// Отладка программы: F5 или меню "Отладка" > "Запустить отладку"

// Советы по началу работы 
//   1. В окне обозревателя решений можно добавлять файлы и управлять ими.
//   2. В окне Team Explorer можно подключиться к системе управления версиями.
//   3. В окне "Выходные данные" можно просматривать выходные данные сборки и другие сообщения.
//   4. В окне "Список ошибок" можно просматривать ошибки.
//   5. Последовательно выберите пункты меню "Проект" > "Добавить новый элемент", чтобы создать файлы кода, или "Проект" > "Добавить существующий элемент", чтобы добавить в проект существующие файлы кода.
//   6. Чтобы снова открыть этот проект позже, выберите пункты меню "Файл" > "Открыть" > "Проект" и выберите SLN-файл.
